
<?php $__env->startSection('title', $news->title); ?>
<?php $__env->startSection('body'); ?>
<h4><?php echo e($news->title); ?></h4>
<i class="fa fa-calendar"></i> <?php echo e(date("d M, y", strtotime($news->created_at))); ?>

<p class="text-justify" style="margin-top:10px;"><?php echo html_entity_decode($news->description); ?></p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMP\htdocs\school\resources\views\menu\news\show.blade.php ENDPATH**/ ?>