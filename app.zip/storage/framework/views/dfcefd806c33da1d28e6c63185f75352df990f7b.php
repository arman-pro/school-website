
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">    
    <title><?php echo $__env->yieldContent('title'); ?>-School Management System</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon">

    
    

    <!-- Font awesome -->
    <link href=<?php echo e(asset('css/font-awesome.css')); ?> rel="stylesheet">
    <!-- Bootstrap -->
    <link href=<?php echo e(asset('css/bootstrap.css')); ?> rel="stylesheet">   
    
    <!-- Slick slider -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/slick.css')); ?>">          
    <!-- Fancybox slider -->
    <link rel="stylesheet" href="<?php echo e(asset('/css/jquery.fancybox.css')); ?>" type="text/css" media="screen" /> 
    <!-- Theme color -->
    <link id="switcher" href="<?php echo e(asset('assets/css/default-theme.css')); ?>" rel="stylesheet">          

    <!-- Main style sheet -->
    <link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">    

   
    <!-- Google Fonts -->
    <link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,400italic,300,300italic,500,700' rel='stylesheet' type='text/css'>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
      marquee {
        background: #4c566a;
      }
      .news {
        margin: 0; 
        padding: 0;
      }

      .news > li {
        list-style-type: none;
        float: left;
        margin: 5px;
        margin-right: 10px;
      }

      .news > li > a {
        color: white;
        text-decoration: none;
      }

      .news > li > a:hover {
        color: #1c7ed6;
      }

    </style>
    <?php echo $__env->yieldContent('mini-style'); ?>

  </head>
  <body> 

  <!--START SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#">
      <i class="fa fa-angle-up"></i>      
    </a>
  <!-- END SCROLL TOP BUTTON -->

  <!-- Start header  -->
  <header id="mu-header">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <div class="mu-header-area">
            <div class="row">
              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                <div class="mu-header-top-left">
                  <div class="mu-top-email">
                    <i class="fa fa-envelope"></i>
                    <span>info@markups.io</span>
                  </div>
                  <div class="mu-top-phone">
                    <i class="fa fa-phone"></i>
                    <span>(568) 986 652</span>
                  </div>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                <div class="mu-header-top-right">
                  <nav>
                    <ul class="mu-top-social-nav">
                     <?php if(auth()->guard()->guest()): ?>
                      <?php if(Route::has('login')): ?>                   
                        <li><a href="<?php echo e(route('login')); ?>">Admin Login</a></li>
                      <?php endif; ?>
                     <?php endif; ?>
                     <?php if(auth()->guard()->check()): ?>
                         <?php if(Route::has('admin')): ?>
                             <li><a target="_blank" class="btn btn-sm btn-outline-info" href="<?php echo e(route('admin')); ?>">Admin Panel</a></li>
                         <?php endif; ?>
                     <?php endif; ?>
                      <li><a href="<?php echo e(route('notice')); ?>">Recent Notice</a></li>
                      <li><a href="<?php echo e(route('news')); ?>">News</a></li>
                      <li><a href="<?php echo e(route('100')); ?>"><b><span class="text-success">100 Years</span> <span class="text-danger">Celebration</span></a></b></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>
  <!-- End header  -->
  <!-- Start menu -->
  <section id="mu-menu">
    <nav class="navbar navbar-default" role="navigation">  
      <div class="container">
        <div class="navbar-header">
          <!-- FOR MOBILE VIEW COLLAPSED BUTTON -->
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <!-- LOGO -->              
          <!-- TEXT BASED LOGO -->
          
          <!-- IMG BASED LOGO  -->
          <!-- <a class="navbar-brand" href="index.html"><img src="assets/img/logo.png" alt="logo"></a> -->
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul id="top-menu" class="nav navbar-nav navbar-right main-nav text-sm">
            <li class="active"><a href=<?php echo e(url("/")); ?>>Home</a></li>            
            <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown">Administration <span class="fa fa-angle-down"></span></a>
              <ul class="dropdown-menu" role="menu">
                <li><a href=<?php echo e(url('/president')); ?>>President</a></li>                
                <li><a href=<?php echo e(url('/principal')); ?>>Principal</a></li>                
                <li><a href=<?php echo e(url('/vice-principal')); ?>>Vice Principal</a></li>                
                <li><a href=<?php echo e(url('/governing-body')); ?>>Governing Body</a></li>                
                <li><a href=<?php echo e(url('/faculty-member')); ?>>Faculty Member</a></li>                
                <li><a href=<?php echo e(url('/office-stuff')); ?>>Office Stuff</a></li>                
              </ul>
            </li> 
            <?php if(!$pages->isEmpty()): ?>
            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo e($page->name); ?> <span class="fa fa-angle-down"></span></a>
              <ul class="dropdown-menu" role="menu">
                <?php $__currentLoopData = $page->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li>
                    <a href="<?php echo e(route('page', ['category'=> $category->id, 'name' => strtolower(implode('-', explode(' ', $category->name))) ])); ?>">
                      <?php echo e($category->name); ?>

                    </a>
                  </li> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>       
              </ul>
            </li> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
      
 
            <li><a href="#" id="mu-search-icon"><i class="fa fa-search"></i></a></li>
          </ul>                     
        </div><!--/.nav-collapse -->        
      </div>     
    </nav>
    <?php if(!$newses->isEmpty()): ?>
    <marquee behavior="" direction="left" style="min-width:100%;width:auto;overflow:hidden;">
      <ul class="news">
      <?php
        $i =0;
        foreach ($newses as $news) {
          $i++;
          if($i == 5) {
            break;
          }
      ?>
       <li><a href="<?php echo e(route('news.show', ['id' => $news->id])); ?>"><?php echo e($news->title); ?></a></li>
      <?php
        }
      ?>      
      </ul>
    </marquee>
    <?php endif; ?>
    
  </section>
  <!-- End menu -->
  <!-- Start search box -->
  <div id="mu-search">
    <div class="mu-search-area">      
      <button class="mu-search-close"><span class="fa fa-close"></span></button>
      <div class="container">
        <div class="row">
          <div class="col-md-12">            
            <form class="mu-search-form">
              <input type="search" placeholder="Type Your Keyword(s) & Hit Enter">              
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Start Slider -->
  <section id="mu-slider">
  
    <!-- Start single slider item -->
    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="mu-slider-single">
      <div class="mu-slider-img">
        <figure>
          <img src=<?php echo e(asset('storage/img/slider/').'/'.$slider->thumbnail); ?> alt="<?php echo e($slider->thumbnail); ?>">
        </figure>
      </div>
      <div class="mu-slider-content">
        <h4><?php echo e($slider->subTitle); ?></h4>
        <span></span>
        <h2><?php echo e($slider->title); ?></h2>
        <p><?php echo e($slider->description); ?></p>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </section>



  <!-- Start service  -->
  <section id="mu-service">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <div class="mu-service-area">
            <!-- Start single service -->
            <div class="mu-service-single">
              <span class="fa fa-book"></span>
              <h3>Teaching</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima officiis, deleniti dolorem exercitationem praesentium, est!</p>
            </div>
            <!-- Start single service -->
            <!-- Start single service -->
            <div class="mu-service-single">
              <span class="fa fa-users"></span>
              <h3>Creativity</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima officiis, deleniti dolorem exercitationem praesentium, est!</p>
            </div>
            <!-- Start single service -->
            <!-- Start single service -->
            <div class="mu-service-single">
              <span class="fa fa-table"></span>
              <h3>Recreation</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima officiis, deleniti dolorem exercitationem praesentium, est!</p>
            </div>
            <!-- Start single service -->
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End service  -->

  <!-- Start about us -->
  <section id="mu-about-us">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-about-us-area">           
            <div class="row">
              <div class="col-lg-6 col-md-6">
                <div class="mu-about-us-left">
                  <!-- Start Title -->
                  <div class="mu-title">
                    <h2>About Us</h2>              
                  </div>
                  <!-- End Title -->
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rerum pariatur fuga eveniet soluta aspernatur rem, nam voluptatibus voluptate voluptates sapiente, inventore. Voluptatem, maiores esse molestiae.</p>
                  <ul>
                    <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</li>
                    <li>Saepe a minima quod iste libero rerum dicta!</li>
                    <li>Voluptas obcaecati, iste porro fugit soluta consequuntur. Veritatis?</li>
                    <li>Ipsam deserunt numquam ad error rem unde, omnis.</li>
                    <li>Repellat assumenda adipisci pariatur ipsam eos similique, explicabo.</li>
                  </ul>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perspiciatis quaerat harum facilis excepturi et? Mollitia!</p>
                </div>
              </div>
              <div class="col-lg-6 col-md-6">
                <div class="mu-about-us-right">                            
                  <img style="width:100%;" src=<?php echo e(asset('/img/school.jpg')); ?> alt="img">              
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End about us -->

<!-- Start about us counter -->
<section id="mu-about-us" >
  <div class="container">
    <div class="row">
      
      
      <div class="sidebar col-md-3">
        <div class="box">
          <h4>Principal's Word</h4>
          <img style="width:100%;" src="<?php echo e(asset('storage/img/teacher')); ?>/<?php echo e($principalMessage[0]->messengerImage); ?>" alt="Teacher Image"/>
          <p><?php echo e(substr($principalMessage[0]->messages, 0, 100)); ?><b>....</b><span><a href="<?php echo e(url('/principal')); ?>">more</a></span></p>
        </div>

        <div class="box">
          <h4>Vice Principal's Word</h4>
          <img style="width:100%;" src="<?php echo e(asset('storage/img/teacher').'/'.$viceMessage[0]->messengerImage); ?>" alt="Teacher Image"/>
          <p><?php echo e(substr($viceMessage[0]->messages, 0, 100)); ?><b>....</b><span><a href="<?php echo e(url('/vice-principal')); ?>">more</a></span></p>
        </div>

      </div>
      
      <div class="col-md-6">

        
        <?php echo $__env->yieldContent('body'); ?>

      </div>

      
      <div class="col-md-3 p-5">
        <div class="list-group">
          <a class="list-group-item active">
            Recent Noticle
          </a>
          <?php if(!$notices->isEmpty()): ?>
            <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a href="<?php echo e(route('details', ['id'=>$notice->id])); ?>" class="list-group-item">
                <?php echo e($notice->title); ?><br/>
                <small class="text-sm text-muted"><?php echo e(date('d M, Y g:i A', strtotime($notice->created_at))); ?></small>
              </a>
              
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
          <li class="list-group-item text-right"> Notice not Found</li>
          <?php endif; ?>         
          <li class="list-group-item text-right">
            <a href="<?php echo e(route('notice')); ?>" class="btn btn-sm btn-danger">See All</a>
          </li>
        </div>

    
      </div>
    </div>
  </div>
</section>


  <br/>

  <!-- Start footer -->
  <footer id="mu-footer">
    <!-- start footer top -->
    <div class="mu-footer-top">
      <div class="container">
        <div class="mu-footer-top-area">
          <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-3">
              <div class="mu-footer-widget">
                <h4>Information</h4>
                <ul>
                  <li><a href="#">About Us</a></li>
                  <li><a href="">Features</a></li>
                  <li><a href="">Course</a></li>
                  <li><a href="">Event</a></li>
                  <li><a href="">Sitemap</a></li>
                  <li><a href="">Term Of Use</a></li>
                </ul>
              </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-3">
              <div class="mu-footer-widget">
                <h4>Recent News</h4>
                <ul>
                <?php if(!$newses->isEmpty()): ?>
                  <?php $__currentLoopData = $newses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><a href="<?php echo e(route("news.show", ['id'=>$news->id])); ?>"><?php echo e($news->title); ?></a></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <li><a href="#">No Recent News Available</a></li>
                <?php endif; ?>               
                </ul>
              </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-3">
              <div class="mu-footer-widget">
                <h4>News letter</h4>
                <p>Get latest update, news & academic offers</p>
                <form class="mu-subscribe-form">
                  <input type="email" placeholder="Type your Email">
                  <button class="mu-subscribe-btn" type="submit">Subscribe!</button>
                </form>               
              </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-3">
              <div class="mu-footer-widget">
                <h4>Contact</h4>
                <address>
                  <p>P.O. Box 320, Ross, California 9495, USA</p>
                  <p>Phone: (415) 453-1568 </p>
                  <p>Website: www.markups.io</p>
                  <p>Email: info@markups.io</p>
                </address>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- end footer top -->
    <!-- start footer bottom -->
    <div class="mu-footer-bottom">
      <div class="container">
        <div class="mu-footer-bottom-area">
          <p>&copy; All Right Reserved. Designed by <a href="http://www.markups.io/" rel="nofollow">MarkUps.io</a></p>
        </div>
      </div>
    </div>
    <!-- end footer bottom -->
  </footer>
  <!-- End footer -->
  
  <!-- jQuery library -->
  <script src=<?php echo e(asset('/js/jquery.min.js')); ?>></script>  
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src=<?php echo e(asset('/js/bootstrap.js')); ?>></script>   
  <!-- Slick slider -->
  <script type="text/javascript" src=<?php echo e(asset('/js/slick.js')); ?>></script>
  <!-- Counter -->
  <script type="text/javascript" src=<?php echo e(asset('/js/waypoints.js')); ?>></script>
  <script type="text/javascript" src=<?php echo e(asset('/js/jquery.counterup.js')); ?>></script>  
  <!-- Mixit slider -->
  <script type="text/javascript" src=<?php echo e(asset('/js/jquery.mixitup.js')); ?>></script>
  <!-- Add fancyBox -->        
  <script type="text/javascript" src=<?php echo e(asset('/js/jquery.fancybox.pack.js')); ?>></script>
  
  
  <!-- Custom js -->
  <script src=<?php echo e(asset('/js/custom.js')); ?>></script> 

</body>
</html><?php /**PATH G:\XAMP\htdocs\school\resources\views\layout\layout.blade.php ENDPATH**/ ?>