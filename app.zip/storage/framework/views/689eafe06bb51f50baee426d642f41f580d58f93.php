<?php $__env->startSection('title', 'Celebrationers List'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-title">
    <h5>Celebrationers List</h5>
    <p class="text-subtitle text-muted">100 Years Celebrations</p>
</div>
<section class="section">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 col-12">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Phone</th>
                                        <th>Session</th>
                                        <th>Registration</th>
                                        <th>&nbsp;</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!$celebrationers->isEmpty()): ?>
                                    <?php $__currentLoopData = $celebrationers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $celebrationer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>#<?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($celebrationer->name); ?></td>
                                        <td><?php echo e($celebrationer->phone); ?></td>
                                        <td><?php echo e($celebrationer->session); ?></td>
                                        <td><?php echo e(date('j M y',strtotime($celebrationer->created_at))); ?></td>
                                        <td>
                                           
                                            <div class="btn-group" role="group">
                                                <button id="btnGroupDrop1" type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i data-feather="settings" width="20"></i>
                                                </button>
                                                <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                                  <a class="dropdown-item text-info" href="#">Update</a>
                                                  <a class="dropdown-item text-danger" href="#">Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php else: ?>
                                    <tr>
                                        <td colspan="6" class="text-muted text-center">No Data Found!!!</td>
                                    </tr>
                                    <?php endif; ?>
                                    
                                </tbody>
                                <footer>
                                    <tr>
                                        <td><b>Total: <?php echo $celebrationers->count() > 0 ? $celebrationers->count() . ' Person\'s': '0'; ;?></b></td>
                                        <td colspan="5" class="text-right">&nbsp;</td>
                                    </tr>
                                </footer>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMP\htdocs\school\resources\views\admin\menu\100\index.blade.php ENDPATH**/ ?>