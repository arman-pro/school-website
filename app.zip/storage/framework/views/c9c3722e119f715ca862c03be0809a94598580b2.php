
<?php $__env->startSection('mini-style'); ?>
<style>
    .panel-body > div >figure > img {
        width: 100%;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', !is_null($content) ? $content->title:ucwords(str_replace('-', ' ', $name))); ?>
<?php $__env->startSection('body'); ?>
<div class="panel panel-primary">
    <div class="panel-heading"><?php echo e(!is_null($content) ? $content->title:ucwords(str_replace('-', ' ', $name))); ?></div>
    <div class="panel-body">
        <?php if(!is_null($content)): ?>
            <?php if(!is_null($content->file)): ?>
            <a target="_blank" href="<?php echo e(route('pdf', ['file' => $content->file])); ?>" class="btn btn-sm btn-info">
                Download Notice
            </a>
            <?php endif; ?>
            <?php if(!is_null($content->content)): ?>
            <div style="margin-top:15px;"> <?php echo str_replace('&rt;', '>', str_replace('&lt;', '<', $content->content)); ?> </div>
            <?php endif; ?>
            <?php if(is_null($content->file) && is_null($content->content)): ?>
                <p class="alert alert-danger">
                    No Data Available
                </p>
            <?php endif; ?>
        <?php else: ?>
            <div class="alert alert-warning">No Data Available</div>
        <?php endif; ?>
       
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMP\htdocs\school\resources\views\menu\single.blade.php ENDPATH**/ ?>