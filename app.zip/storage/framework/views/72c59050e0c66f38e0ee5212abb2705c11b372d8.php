

<?php $__env->startSection('title', "Pricipal ".$message[0]->messengerName."'s message"); ?>
<?php $__env->startSection('body'); ?>
<div class="panel panel-primary">
    <div class="panel-heading">Message Of Principal</div>
    <div class="panel-body">
        <img class="thumbnail" style="width:250px;margin:auto;" src="<?php echo e(asset('storage/img/teacher')); ?>/<?php echo e($message[0]->messengerImage); ?>" alt="Teacher Image"/>
        <p class="text-justify"><?php echo e($message[0]->messages); ?></p>
        <p>
            <b><?php echo e($message[0]->messengerName); ?></b><br/>
            <b><?php echo e($message[0]->position); ?></b><br/>
        </p>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamp\htdocs\school\resources\views/menu/administration/principal.blade.php ENDPATH**/ ?>