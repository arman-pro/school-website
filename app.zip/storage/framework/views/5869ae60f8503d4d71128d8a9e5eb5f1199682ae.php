
<?php $__env->startSection('title', 'Administration Person\'s Message'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-title">
    <h3>Administrations Person's Messages</h3>
    <p class="text-subtitle text-muted">Write and Update Administrations Person's Message</p>
</div>
<section class="section">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 col-12">
                            <div class="p-2">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Messenger</th>
                                            <th>Profile</th>
                                            <th>Messages</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-sm">
                                                <p class="p-0"> <b><?php echo e($message->messengerName); ?></b></p>
                                                <p class="p-0"> <b><?php echo e($message->position); ?></b></p>
                                                </td>
                                                <td>
                                                    <img style="width:100px;" class="thumbnail-img" src="<?php echo e(asset('storage/img/teacher').'/'.$message->messengerImage); ?>" alt="Teacher Image">
                                                </td>
                                                <td>
                                                    <p class="text-sm text-justify"><?php echo e($message->messages); ?></p>
                                                </td>
                                                <td>
                                                    <a href=<?php echo e(route('admin.edit', ['id' => $message->id])); ?> class="btn btn-sm btn-primary">Update</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </tbody>
                                </table>
                            </div>    
                        </div>
                        
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamp\htdocs\school\resources\views/admin/menu/administration/message.blade.php ENDPATH**/ ?>