<?php
    $title = ucwords(join(' ', explode('-', $page)));
?>

<?php $__env->startSection('title', 'Create '.$title); ?>
<?php $__env->startSection('content'); ?>
<div class="page-title">
    <h5><?php echo e($title); ?></h5>
    <p class="text-subtitle text-muted">Create New <?php echo e($title); ?> Member</p>
</div>
<section class="section">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 col-12">
                            <?php if($page): ?>
                                <a href="<?php echo e(url("/admin/$page")); ?>" class="btn btn-sm btn-info">Back</a>
                            <?php endif; ?>
                            <?php if(session('message')): ?>
                                <div class="alert alert-success mt-2"><?php echo e(session('message')); ?></div>
                            <?php endif; ?>
                            <form action="<?php echo e(route('admin.officer.create')); ?>" method="post" enctype="multipart/form-data" class="p-2">
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <div class="col-md-6 col-sm-12">
                                        <label for="page">Administrative Section</label>
                                        <select name="page" id="page" class="form-control mt-2" required>
                                            <option value="" hidden>Select Section</option>
                                            <option value="governing-body" <?php echo e($page=='governing-body'?'selected':null); ?> >Governing Body</option>
                                            <option value="faculty-member" <?php echo e($page=='faculty-member'?'selected':null); ?>>Faculty Member</option>
                                            <option value="office-stuff" <?php echo e($page=='office-stuff'?'selected':null); ?>>Office Stuff</option>
                                        </select>
                                        <?php $__errorArgs = ['page'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger pt-1"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6 col-sm-12">
                                        <label for="name">Member Name</label>
                                        <input type="text" name="name" id="id" class="form-control mt-2" placeholder="Ex. Jone Doe" value="<?php echo e(old('name')); ?>" <?php echo e(!empty($page)? 'autofocus="true"':null); ?> />
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger pt-1"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            
                                <div class="form-group row">
                                    <div class="col-md-6 col-sm-12">
                                        <label for="position">Member Positon/Job</label>
                                        <input type="text" name="position" id="position" class="form-control mt-2" placeholder="<?php echo e($page=='faculty-member'?'Ex. Lecturer of Economics':null); ?> <?php echo e($page=='governing-body'?'President of School Committee':null); ?> <?php echo e($page=='office-stuff'?'Administrative Officer':null); ?>" value="<?php echo e(old('position')); ?>" />
                                        <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger pt-1"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6 col-sm-12">
                                        <label for="image">Member Image</label>
                                        <input type="file" name="image" id="image" class="form-control mt-2" />
                                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger pt-1"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label for="description">Description</label>
                                    <textarea name="description" id="description" cols="30" rows="3" class="form-control mt-2" value="<?php echo e(old('description')); ?>" placeholder="Description"></textarea>
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger pt-1"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-check">
                                    <input type="checkbox" name="descriptionNotApplicable" class="form-check-input" value="yes" id="exampleCheck1">
                                    <label class="form-check-label" for="exampleCheck1">Description Not Applicable</label>
                                  </div>
                                <div class="form-group" style="text-align:right">
                                    <button type="submit" class="btn btn-sm btn-primary">Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMP\htdocs\school\resources\views\admin\menu\administration\officer.blade.php ENDPATH**/ ?>