
<?php $__env->startSection('title', 'All news list'); ?>
<?php $__env->startSection('body'); ?>

<div class="list-group">
    <a class="list-group-item active">
        All News
      </a>
    <?php if(!$all_newses->isEmpty()): ?>
        <?php $__currentLoopData = $all_newses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('news.show', ['id'=>$news->id])); ?>" class="list-group-item">
            <?php echo e($news->title); ?><br/>   
            <small class="text-sm text-muted">Publis at: <?php echo e(date('d M, y', strtotime($news->created_at))); ?></small>
        </a>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <li class="list-group-item text-right"> Notice not Found</li>
    <?php endif; ?>         
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMP\htdocs\school\resources\views\menu\news\index.blade.php ENDPATH**/ ?>