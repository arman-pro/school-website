
<?php $__env->startSection('title', $notice->title); ?>
<?php $__env->startSection('body'); ?>
<div class="panel panel-primary">
  <div class="panel-heading"><?php echo e($notice->title); ?></div>
  <div class="panel-body">
    <?php if(!is_null($notice->file_name)): ?>
      <div class="alert alert-info">
        Attach Pdf File Download  
        <a target="_blank" href="<?php echo e(route('pdf', ['file'=> $notice->file_name])); ?>" class="btn btn-sm btn-primary" style="float:right" title="click here for downloading">Download</a>
      </div>
    <?php endif; ?>
    <p class="text-muted text-xs">
      Published At: <b><?php echo e(date('j F, Y g:i A', strtotime($notice->created_at))); ?></b> <br/>
      Last Updated: <b><?php echo e(date('j F, Y g:i A', strtotime($notice->updated_at))); ?></b>
    </p>
   <?php if(!is_null($notice->content)): ?>
   <p class="text-justify">
    <?php echo e($notice->content); ?>

  </p>
   <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMP\htdocs\school\resources\views\menu\notice-view.blade.php ENDPATH**/ ?>