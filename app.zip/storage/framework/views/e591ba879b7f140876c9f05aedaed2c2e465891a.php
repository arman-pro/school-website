<?php $__env->startSection('title', 'Control Your Application'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-title">
    <h5>Page & Category List</h5>
    <p class="text-subtitle text-muted">Create and Update Your Page & Category</p>
</div>
<div class="row">
    <div class="col-12">
        <?php if(session('message')): ?>
            <div class="alert alert-success"><?php echo e(session('message')); ?></div>
        <?php endif; ?>
        <?php if(session('delete')): ?>
            <div class="alert alert-danger"><?php echo e(session('delete')); ?></div>         
        <?php endif; ?>
    </div>
</div>
<section class="section">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8 col-12">
                            <h5 class="page-title">Page List</h5>
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Page</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!$pages->isEmpty()): ?>
                                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>#<?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($page->name); ?></td>
                                        <td class="d-inline-block">
                                            <a href="<?php echo e(route('admin.category').'?'.http_build_query(['id'=>$page->id, 'sub'=>'page', 'action'=>'edit'])); ?>" class="btn btn-sm btn-primary">Update</a>
                                            <form style="display:inline" action="<?php echo e(route('admin.page.delete', ['id' => $page->id])); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="btn btn-sm btn-danger" >Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <tr>
                                        <td colspan="3" class="text-muted text-center">No Page Found</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="col-md-4 col-12">
                            <?php if(!is_null($pageUp)): ?>
                                <h5 class="page-title">Update Page</h5>
                                <div class="p-3">
                                    <form action="<?php echo e(route('admin.page.update', ['id'=>$pageUp->id])); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="form-group">
                                            <label for="page">Page Name</label>
                                            <input type="text" name="page" class="form-control mt-2" id="page" placeholder="Page Name" autofocus="true" value="<?php echo e($pageUp->name); ?>" required />
                                            <?php $__errorArgs = ['page'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><b><?php echo e($message); ?></b></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-sm btn-success">Update</button>
                                        </div>
                                    </form>
                                </div>
                            <?php else: ?>
                            <h5 class="page-title">Page Create</h5>
                            <div class="p-3">
                                <form action="<?php echo e(route('admin.page.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="page">Page Name</label>
                                        <input type="text" name="page" class="form-control mt-2" id="page" placeholder="Page Name" required />
                                        <?php $__errorArgs = ['page'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><b><?php echo e($message); ?></b></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-sm btn-success">Save</button>
                                    </div>
                                </form>
                            </div>
                            <?php endif; ?>
                            
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8 col-12">
                            <h5 class="page-title">Category List</h5>
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Category</th>
                                        <th>Page</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!$categories->isEmpty()): ?>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>#<?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($category->name); ?></td>
                                            <td><?php echo e($category->page->name); ?></td>
                                            <td style="width:38%;">
                                                <a href="<?php echo e(route('admin.category').'?'.http_build_query(['id'=>$category->id,'sub'=>'category', 'action'=>'edit'])); ?>" class="btn btn-sm btn-primary">Update</a>

                                                <button class="btn btn-sm btn-danger" onclick="document.querySelector('#category-delete').submit()" >Delete</button>
                                                <form id="category-delete" action="<?php echo e(route('admin.category.delete', ['id'=>$category->id])); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                </form>
                                                
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <tr>
                                        <td colspan="4" class="text-muted text-center" style="text-align:center">No Category Found</td>
                                    </tr>
                                    <?php endif; ?>
                                    
                                </tbody>
                            </table>
                        </div>
                        <div class="col-md-4 col-12">
                            <?php if(!is_null($cate)): ?>
                            <h5 class="page-title">Category Update</h5>
                            <form action="<?php echo e(route('admin.category.update', ['id'=>$cate->id])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="form-group">
                                    <label for="pageId">Select Page</label>
                                    <select name="pageId" id="pageId" class="form-control mt-2">
                                        <option value="" hidden>Select Page</option>
                                        <?php if(!$pages->isEmpty()): ?>
                                        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e($pa->id==$cate->page_id?'selected':null); ?> value="<?php echo e($pa->id); ?>"><?php echo e($pa->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <option value="">No Page Avaliable</option>
                                        <?php endif; ?>
                                    </select>
                                    <?php $__errorArgs = ['pageId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="category">Category Name</label>
                                    <input type="text" name="category" class="form-control mt-2" id="category" placeholder="Category Name" autofocus="true" value="<?php echo e($cate->name); ?>" />
                                    <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><b><?php echo e($message); ?></b></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-sm btn-success">Update</button>
                                </div>
                            </form>
                            <?php else: ?>
                            <h5 class="page-title">Category Create</h5>
                            <form action="<?php echo e(route('admin.cateogry.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="pageId">Select Page</label>
                                    <select name="pageId" id="pageId" class="form-control mt-2" required>
                                        <option value="" hidden>Select Page</option>
                                        <?php if(!$pages->isEmpty()): ?>
                                        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($page->id); ?>"><?php echo e($page->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <option value="">No Page Avaliable</option>
                                        <?php endif; ?>
                                    </select>
                                    <?php $__errorArgs = ['pageId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="category">Category Name</label>
                                    <input type="text" name="category" class="form-control mt-2" id="category" value="<?php echo e(old('category')); ?>" placeholder="Category Name" required />
                                    <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><b><?php echo e($message); ?></b></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-sm btn-success">Save</button>
                                </div>
                            </form>
                            <?php endif; ?>
                            
                        </div>

                    </div>
                </div>
            </div>           

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamp\htdocs\school\resources\views/admin/menu/category/index.blade.php ENDPATH**/ ?>