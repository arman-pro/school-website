<?php $__env->startSection('title', 'Celebrationers List'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-title">
    <h5>Celebrationers List</h5>
    <p class="text-subtitle text-muted">100 Years Celebrations</p>
</div>
<section class="section">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 col-12">
                            <div class="row">
                                <form action="<?php echo e(route('admin.100.fee', ['id' => $fee[0]->id??20])); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="col-md-6 col-sm-12">
                                        <label for="fee">Set Registration Fee</label>
                                        <input type="number" name="fee" class="form-control mb-2" id="fee" value="<?php echo e($fee[0]->fee??20); ?>" placeholder="Set Registration Fee" />
                                        <?php $__errorArgs = ['fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <button type="submit" class="btn btn-secondary">Update</button>
                                    </div>
                                </form>
                            </div>
                            <?php if(session('delete')): ?>
                                <div class="alert alert-danger mt-2"><?php echo e(session('delete')); ?></div>
                            <?php endif; ?>
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Phone</th>
                                        <th>Profession</th>
                                        <th>Session</th>
                                        <th>Registration</th>
                                        <th>&nbsp;</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!$celebrationers->isEmpty()): ?>
                                    <?php $__currentLoopData = $celebrationers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $celebrationer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>#<?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($celebrationer->name); ?></td>
                                        <td><?php echo e($celebrationer->phone); ?></td>
                                        <td><?php echo e($celebrationer->profession); ?></td>
                                        <td><?php echo e($celebrationer->session ? $celebrationer->session : 'N/A'); ?></td>
                                        <td><?php echo e(date('j M y',strtotime($celebrationer->created_at))); ?></td>
                                        <td>
                                           
                                            <div class="btn-group" role="group">
                                                <button id="btnGroupDrop1" type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i data-feather="settings" width="20"></i>
                                                </button>
                                                <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                                  <a class="dropdown-item text-success" target="_blank" href="<?php echo e(route('admin.100.view', ['id' => $celebrationer->id])); ?>">View</a>
                                                  <a class="dropdown-item text-info" href="#">Update</a>
                                                <form action="<?php echo e(route('admin.100.delete', ['id' => $celebrationer->id])); ?>" method="post">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>
                                                  <button class="dropdown-item text-danger" type="submit" >Delete</button>
                                                </form>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php else: ?>
                                    <tr>
                                        <td colspan="7" class="text-muted text-center">No Data Found!!!</td>
                                    </tr>
                                    <?php endif; ?>
                                    
                                </tbody>
                                <footer>
                                    <tr>
                                        <td><b>Total: <?php echo $celebrationers->count() > 0 ? $celebrationers->count() . ' Person\'s': '0'; ;?></b></td>
                                        <td colspan="6" class="text-right">&nbsp;</td>
                                    </tr>
                                </footer>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamp\htdocs\school\resources\views/admin/menu/100/index.blade.php ENDPATH**/ ?>