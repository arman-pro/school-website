<?php $__env->startSection('title', 'Celebrationers Expense List'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-title">
    <h5>Asset
    </h5>
    <p class="text-subtitle text-muted">100 Years Celebrations Assets</p>
</div>
<section class="section">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <table class="table table-bordered">
                                <tbody>
                                    <tr>
                                        <td>Asset <?php if($amounts->isNotEmpty()): ?>
                                            <b> (<?php echo e($amounts[0]->persons); ?>)</b>
                                        <?php endif; ?> </td>
                                        <td>
                                            <?php if($amounts->isNotEmpty()): ?>
                                                <b><?php echo e($amounts[0]->amount); ?></b>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php if($expenses->isNotEmpty()): ?>
                                    <tr>
                                        <td>Expense <b>(<?php echo e($expenses[0]->total); ?>)</b></td>
                                        <td><b><?php echo e($expenses[0]->amount); ?></b></td>
                                    </tr>
                                    <?php endif; ?>
                                    
                                    <tr>
                                        <td>Total:</td>
                                        <td><b><?php echo e($amounts[0]->amount - $expenses[0]->amount); ?></b></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMP\htdocs\school\resources\views/admin/menu/100/asset.blade.php ENDPATH**/ ?>