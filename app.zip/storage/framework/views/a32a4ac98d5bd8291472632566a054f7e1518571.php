<?php
    $title = ucwords(join(' ', explode('-', $page)));
?>

<?php $__env->startSection('title', "Edit $title"); ?>
<?php $__env->startSection('content'); ?>
<div class="page-title">
    <h5>Edti <?php echo e($title); ?></h5>
    <p class="text-subtitle text-muted">Edit <?php echo e($title); ?> Member</p>
</div>
<section class="section">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 col-12">
                            <div class="p-1">
                                <a href="<?php echo e(url('/admin').'/'.$page); ?>" class="btn btn-sm btn-info">Back</a>
                            </div>
                            <?php if(session('message')): ?>
                                <div class="alert alert-success"><?php echo e(session('message')); ?></div>
                            <?php endif; ?>
                            <form action=<?php echo e(route('admin.officer.update', ['id'=>$officer->id])); ?> method="post" enctype="multipart/form-data" class="p-2">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="form-group row">
                                    <div class="col-md-6 col-sm-12">
                                        <label for="page">Administrative Section</label>
                                        <select name="page" id="page" class="form-control mt-2" autofocus="true" required>
                                            <option value="" hidden>Select Section</option>
                                            <option value="governing-body" <?php echo e($officer->page=='governing-body'?'selected':null); ?> >Governing Body</option>
                                            <option value="faculty-member" <?php echo e($officer->page=='faculty-member'?'selected':null); ?>>Faculty Member</option>
                                            <option value="office-stuff" <?php echo e($officer->page=='office-stuff'?'selected':null); ?>>Office Stuff</option>
                                        </select>
                                        <?php $__errorArgs = ['page'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger pt-1"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6 col-sm-12">
                                        <label for="name">Member Name</label>
                                        <input type="text" name="name" id="id" class="form-control mt-2" placeholder="Ex. Jone Doe" value="<?php echo e($officer->name); ?>" />
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger pt-1"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            
                                <div class="form-group row">
                                    <div class="col-md-6 col-sm-12">
                                        <label for="position">Member Positon/Job</label>
                                        <input type="text" name="position" id="position" class="form-control mt-2" placeholder="Ex. Lecturer of Economics/President of School Committee" value="<?php echo e($officer->job); ?>" />
                                        <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger pt-1"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-4 col-sm-12">
                                        <label for="image">Member Image</label>
                                        <input type="file" name="image" id="image" class="form-control mt-2" accept=".png, .jpg, .jpeg" />
                                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger pt-1"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-2 col-sm-12">
                                        <img style="width:80px;" src="<?php echo e(asset('/storage/img/teacher').'/'.$officer->image); ?>" alt="<?php echo e($officer->image); ?>" class="img-thumbnail"/>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label for="description">Description</label>
                                    <textarea name="description" id="description" cols="30" rows="3" class="form-control mt-2" placeholder="Description"><?php echo e($officer->description); ?></textarea>
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger pt-1"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-check">
                                    <input type="checkbox" name="descriptionNotApplicable" class="form-check-input" value="yes" id="exampleCheck1">
                                    <label class="form-check-label" for="exampleCheck1">Description Not Applicable</label>
                                  </div>
                                <div class="form-group" style="text-align:right">
                                    <button type="submit" class="btn btn-sm btn-primary">Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMP\htdocs\school\resources\views\admin\menu\administration\edit-officer.blade.php ENDPATH**/ ?>