
<?php $__env->startSection('title', 'Administration Person\'s Message'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-title">
    <h5>Administrations Person's Messages Edit</h5>
    <p class="text-subtitle text-muted">Write and Update Administrations Person's Message</p>
</div>
<section class="section">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 col-12"> 
                            <p class="p-1">
                                <a href="<?php echo e(url('/admin/messages')); ?>" class="btn btn-sm btn-info">Back</a>    
                            </p>  
                            <?php if(session('message')): ?>
                                <div class="alert alert-success"><?php echo e(session('message')); ?></div>
                            <?php endif; ?>                             
                            <form class="p-2" action=<?php echo e(route('admin.message.store', ['id'=>$message->id])); ?> method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-body p-3">
                                    <div class="form-group">
                                        <div class="col-md-12 col-sm-12">
                                            <label for="teacher">Teacher Name</label>
                                            <input type="text" name="teacher" id="teacher" class="form-control mt-1" placeholder="Name" value="<?php echo e($message->messengerName); ?>" />
                                            <?php $__errorArgs = ['teacher'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-sm text-danger p-0"><b><?php echo e($message); ?></b></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form group">
                                        <img style="width:150px;" src="<?php echo e(asset('/storage/img/teacher').'/'.$message->messengerImage); ?>" alt="<?php echo e($message->messengerImage); ?>" class="img-thumbnail">
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-6 col-sm-12">
                                            <label for="image">Image</label>
                                            <input type="file" name="image" id="image" class="form-control mt-1" />
                                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-sm text-danger p-0"><b><?php echo e($message); ?></b></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-6 col-sm-12">
                                            <label for="position">Position</label>
                                            <input type="text" name="position" id="position" class="form-control mt-1" placeholder="Position" value="<?php echo e($message->position); ?>" />
                                            <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-sm text-danger p-0"><b><?php echo e($message); ?></b></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        
                                    </div>
                                    <div class="form-group">
                                        <label for="message">Message</label>
                                        <textarea name="message" id="message" cols="30" rows="5" class="form-control" placeholder="Write Message"><?php echo e($message->messages); ?></textarea>
                                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-sm text-danger p-0"><b><?php echo e($message); ?></b></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group" style="text-align:right">
                                        <button type="submit" class="btn btn-sm btn-success">Save</button>
                                    </div>
                                </div>
                            </form> 
                        </div>                        
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMP\htdocs\school\resources\views\admin\menu\administration\edit-message.blade.php ENDPATH**/ ?>