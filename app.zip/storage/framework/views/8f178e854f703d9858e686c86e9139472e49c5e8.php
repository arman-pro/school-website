

<?php $__env->startSection('title', "President's Message"); ?>
<?php $__env->startSection('body'); ?>
<div class="panel panel-primary">
    <div class="panel-heading">Message Of President</div>
    <div class="panel-body">
        <img class="thumbnail" style="width:250px;margin:auto;" src="<?php echo e(asset('storage/img/teacher')); ?>/<?php echo e($message[0]->messengerImage); ?>" alt="Teacher Image: <?php echo e($message[0]->messengerImage); ?>"/>
       <p class="text-justify"><?php echo e($message[0]->messages); ?></p>
        <p>
            <b><?php echo e($message[0]->messengerName); ?></b><br/>
            <b><?php echo e($message[0]->position); ?></b><br/>
            
        </p>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMP\htdocs\school\resources\views\menu\administration\president.blade.php ENDPATH**/ ?>