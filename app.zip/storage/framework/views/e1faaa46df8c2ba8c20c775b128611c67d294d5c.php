<?php $__env->startSection('title', 'Celebrationers Expense List'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-title">
    <h5>Asset
    </h5>
    <p class="text-subtitle text-muted">100 Years Celebrations Assets</p>
</div>
<section class="section">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <table class="table table-bordered">
                                <tbody>
                                    <tr>
                                        <td>Asset</td>
                                        <td>5000</td>
                                    </tr>
                                    <tr>
                                        <td>Expense</td>
                                        <td>2000</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Celebrationers Expense List'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-title">
    <h5>Asset
    </h5>
    <p class="text-subtitle text-muted">100 Years Celebrations Assets</p>
</div>
<section class="section">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th class="text-center" colspan="2">Asset List</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Asset</td>
                                        <td>5000</td>
                                    </tr>
                                    <tr>
                                        <td>Expense</td>
                                        <td>2000</td>
                                    </tr>
                                    <tr>
                                        <td>Total</td>
                                        <td>3000</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMP\htdocs\school\resources\views\admin\menu\100\assets.blade.php ENDPATH**/ ?>