

<?php $__env->startSection('title', 'Office Stuff'); ?>
<?php $__env->startSection('body'); ?>
<div class="panel panel-primary">
    <div class="panel-heading">Office Stuff</div>
    <div class="panel-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Image</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>
                <?php if(!$officers->isEmpty()): ?>
                <?php $__currentLoopData = $officers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $officer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td>
                            <img style="width:100px;" src=<?php echo e(asset('storage/img/teacher'.'/'.$officer->image)); ?> alt="<?php echo e($officer->image); ?>"/>
                        </td>
                        <td class="text-sm">
                            <p style="margin-bottom:3px;"><b><?php echo e($officer->name); ?></b></p>
                            <p class="text-muted">
                                <b><?php echo e($officer->job); ?></b>
                            </p>
                            <p class="text-justify">
                                <?php echo e($officer->description); ?>

                            </p>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <tr>
                    <td class='text-sm text-muted' colspan="3" style="text-align:center">No Data Available</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMP\htdocs\school\resources\views\menu\administration\office.blade.php ENDPATH**/ ?>