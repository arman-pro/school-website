<?php $__env->startSection('title', $news->title); ?>
<?php $__env->startSection('content'); ?>
<div class="page-title">
    <h5>Show News</h5>
    <p class="text-subtitle text-muted">Show News Details</p>
</div>
<section class="section">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 col-12">
                        <a href="<?php echo e(route('admin.news')); ?>" class="btn btn-sm btn-success mb-2">Back</a>
                            <h3><?php echo e($news->title); ?></h3>
                            <div class="text-justify">
                               <?php echo html_entity_decode($news->description); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMP\htdocs\school\resources\views\admin\menu\news\show.blade.php ENDPATH**/ ?>