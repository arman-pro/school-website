
<?php $__env->startSection('title', 'All Recent Notice'); ?>
<?php $__env->startSection('body'); ?>
<div class="panel panel-primary">
  <div class="panel-heading">All Notice List</div>
  <div class="panel-body">
    <table class="table table-striped">
      <thead>
        <tr>
          <th>Title</th>
          <th>Published</th>
          <th>&nbsp;</th>
        </tr>
      </thead>
      <tbody>
        <?php if(!$notices->isEmpty()): ?>
          <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>
              <span class="text-danger">#<?php echo e($loop->iteration); ?></span> <a href="<?php echo e(route('details', ['id'=>$notice->id])); ?>"> <?php echo e($notice->title); ?></a>
            </td>
            <td class="text-sm">
              <?php echo e(date('d M, y g:i A', strtotime($notice->created_at))); ?>

            </td>
            <td>
              <?php if(!is_null($notice->file_name)): ?>
              <a title="click here for download" target="_blank" href="<?php echo e(route('pdf', ['file' => $notice->file_name])); ?>" class="btn btn-sm btn-primary">Download</a>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          <tr>
            <td colspan="3" class="text-muted text-center">Not Notice Found</td>
          </tr>
        <?php endif; ?>
      </tbody>
      
    </table>
  
    <div class="btn-group">
      <?php if(!is_null($notices->nextPageUrl())): ?>
        <a href="<?php echo e($notices->nextPageUrl()); ?>" class="btn btn-sm btn-info">Next</a>
      <?php endif; ?>
      <?php if(!is_null($notices->previousPageUrl())): ?>
        <a href="<?php echo e($notices->previousPageUrl()); ?>" class="btn btn-sm btn-info">Previous</a>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMP\htdocs\school\resources\views\menu\notice.blade.php ENDPATH**/ ?>