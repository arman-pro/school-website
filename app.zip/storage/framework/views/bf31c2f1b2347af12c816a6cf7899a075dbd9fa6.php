
<?php $__env->startSection('title', 'Show All Notice'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-title">
    <h5>Notice List</h5>
    <p class="text-subtitle text-muted">A good admin panel to maintain your Application</p>
</div>
<section class="section">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 col-12">
                            <?php if(session('message')): ?>
                                <div class="alert alert-success"><?php echo e(session('message')); ?></div>
                            <?php endif; ?>
                            <?php if(session('invalid')): ?>
                            <div class="alert alert-danger"><?php echo e(session('invalid')); ?></div>
                            <?php endif; ?>
                            <form style="padding:10px;border:1px solid #ddd;border-radius:5px;" action="<?php echo e(route('admin.notice.store')); ?>" enctype="multipart/form-data" method="POST">
                                <?php echo csrf_field(); ?>
                                <h6>Create New Notice</h6>
                                
                                <div class="form-group row">
                                    <div class="col-md-6 col-sm-12">
                                        <label for="title">Title</label>
                                        <input type="text" name="title" id="title" class="form-control mt-2" placeholder="Write Title" value="<?php echo e(old('title')); ?>" />
                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6 col-sm-12">
                                        <label for="pdf">Pdf</label>
                                        <input type="file" name="pdf" id="pdf" class="form-control mt-2" value="<?php echo e(old('pdf')); ?>"/>
                                        <input type="checkbox" name="notPdf" id="notPdf" /> <label for="notPdf">Pdf/Image Not Applicable</label><br/>
                                        <?php $__errorArgs = ['pdfImage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="description">Description</label>
                                    <textarea name="description" class="form-control mt-2" id="description" cols="30" rows="5" placeholder="Write Description"><?php echo e(old('description')); ?></textarea>
                                    <input type="checkbox" name="descriptionNotApplicable" id="notDesc" /> <label for="notDesc">Description Not Applicable</label><br/>
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-sm btn-info">Save</button>
                                </div>
                            </form>
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Title</th>
                                        <th>File/Description</th>
                                        <th>Publish</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!$notices->isEmpty()): ?>
                                    <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>#<?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($notice->title); ?></td>
                                        <td>
                                            <?php if(!is_null($notice->file_name)): ?>
                                                <a target="_blank" title="click for view and download" href="<?php echo e(route('admin.pdf', ['file' => $notice->file_name])); ?>" class="btn btn-sm btn-info">View Pdf</a>
                                            <?php endif; ?>
                                            <?php if(!is_null($notice->content)): ?>
                                                <p title="Description" class="text-justify" style="padding:5px;margin-top:5px;margin-bottom:5px;border:1px solid #ddd;border-radius:5px;">
                                               <?php echo e($notice->content); ?>

                                            </p>
                                            <?php endif; ?>

                                        </td>
                                        <td>
                                            <?php echo e(date('d-M-y g:i A', strtotime($notice->created_at))); ?>

                                        </td>
                                        <td style="width:32%;">
                                            <a href="<?php echo e(route('admin.notice.edit', ['id'=>$notice->id])); ?>" class="btn btn-sm btn-success">Update</a>
                                            <form style="display:inline" action="<?php echo e(route('admin.notice.destroy', ['id' => $notice->id])); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                            </form>
                                            
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="text-muted">Notice not Available</td>
                                    </tr>
                                    <?php endif; ?>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMP\htdocs\school\resources\views\admin\menu\notice\index.blade.php ENDPATH**/ ?>