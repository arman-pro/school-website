
<?php $__env->startSection('title', $slider->title); ?>
<?php $__env->startSection('content'); ?>
<div class="page-title">
    <h5>Show Slider</h5>
    <p class="text-subtitle text-sm text-muted">Create, Edit and Delete your Sliders</p>
</div>
<section class="section">
    
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header pb-3">
                    <a href=<?php echo e(url('admin/sliders')); ?> class="btn btn-sm btn-info">Back</a>
                    <a href=<?php echo e(route('slider.create')); ?> class="btn btn-sm btn-success">Create New</a>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 col-12 text-secondary">
                            <div class="img-thumbnail">
                                <img class="img-fluid" style="width:100%;" src="<?php echo e(asset('/storage/img/slider')); ?>/<?php echo e($slider->thumbnail); ?>" alt="Thumbanail Image">
                                <div class="p-2">
                                    <p class="text-sm"><?php echo e($slider->subTitle); ?></p>
                                    <h3><?php echo e($slider->title); ?></h3>
                                    <p class="text-sm">
                                        <?php echo e($slider->description); ?>

                                    </p>
                                </div>
                            </div>
                            <div class="alert alert-secondary mt-2" style='text-align:right;'>
                                <?php if($previousId): ?>
                                    <a href=<?php echo e(route('slider.show', ['id'=> $previousId])); ?> class="btn btn-sm btn-primary">Previous</a>
                                <?php endif; ?>
                                <?php if($nextId): ?>
                                <a href=<?php echo e(route('slider.show', ['id' => $nextId])); ?> class="btn btn-sm btn-primary">Next</a>
                                <?php endif; ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</section>
<script>
    /** 
     * delete slider functiona for accept 
     * @params  {int} id
    */

    function deleteSlider(id) {
        // let accept = confirm('Are you sure to delete');
        // if(accept) {
        //     window.location.href = `./admin/sliders/${id}/delete`;
        // }else {
        //     return;
        // }
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMP\htdocs\school\resources\views\admin\menu\slider\show.blade.php ENDPATH**/ ?>