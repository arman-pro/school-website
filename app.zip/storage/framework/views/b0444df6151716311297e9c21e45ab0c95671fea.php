<?php $__env->startSection('title', 'View Content'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-title">
    <h5>View Content</h5>
    <p class="text-subtitle text-muted">View content</p>
</div>
<section class="section">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 col-12">
                            <a href="<?php echo e(route('admin.content')); ?>" class="btn btn-sm btn-primary mb-5">Back</a>
                            <div class="p-2">
                                <?php if(!is_null($content)): ?>
                                    <h5><?php echo e($content->title); ?></h5>
                                    <p class="text-muted">
                                        <small>Page: <?php echo e($content->page->name); ?> &nbsp;&nbsp; Sub-Page: <?php echo e($content->category->name); ?></small>
                                    </p>
                                    <?php if(!is_null($content->file)): ?>
                                    <p>
                                        Pdf File: <a target="_blank" href="<?php echo e(route('admin.pdf', ['file' => $content->file])); ?>"><?php echo e($content->file); ?></a>
                                    </p>
                                    <?php endif; ?>
                                    <?php if(!is_null($content->content)): ?>
                                        <div class="text-justify mt-2">
                                            <?php echo str_replace('&rt;', '>', str_replace('&lt;', '<', $content->content)); ?>

                                        </div>
                                    <?php endif; ?>
                                    
                                <?php else: ?>
                                    <div class="alert alert-secondary">No Found!</div>
                                <?php endif; ?>
                            </div>                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMP\htdocs\school\resources\views\admin\menu\content\view.blade.php ENDPATH**/ ?>