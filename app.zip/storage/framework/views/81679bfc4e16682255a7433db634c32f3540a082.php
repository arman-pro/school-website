<?php $__env->startSection('title', 'Control Your Application'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-title">
    <h5>Admin Panel</h5>
    <p class="text-subtitle text-muted">A good admin panel to maintain your Application</p>
</div>
<section class="section">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 col-12">
                            <a href="<?php echo e(route('amdin.notice')); ?>" class="btn btn-sm btn-info mb-2">Back</a>
                            <form style="padding:10px;border:1px solid #ddd;border-radius:5px;" action="<?php echo e(route('admin.notice.update', ['id'=> $notice->id])); ?>" enctype="multipart/form-data" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <h6>Update Notice</h6>
                                <?php if(session('message')): ?>
                                    <div class="alert alert-success"><?php echo e(session('message')); ?></div>
                                <?php endif; ?>
                                <?php if(session('invalid')): ?>
                                    <div class="alert alert-success"><?php echo e(session('invalid')); ?></div>
                                <?php endif; ?>
                                
                                <div class="form-group row">
                                    <div class="col-md-6 col-sm-12">
                                        <label for="title">Title</label>
                                        <input type="text" name="title" id="title" class="form-control mt-2" placeholder="Write Title" value="<?php echo e($notice->title); ?>" />
                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-3 col-sm-12">
                                        <label for="pdf">Pdf</label>
                                        <input type="file" name="pdf" id="pdf" class="form-control mt-2" value="<?php echo e(old('pdf')); ?>"/>
                                        <input type="checkbox" name="pdfNot" id="notPdf" /> <label for="notPdf">Pdf Not Applicable</label><br/>
                                        <?php $__errorArgs = ['pdf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-3 col-sm-12">
                                        <label for="">&nbsp;</label>
                                        <div class="form-control mt-2" ><a target="_blank" href="<?php echo e(route('admin.pdf', ['file'=>$notice->file_name])); ?>">View Old File</a></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="description">Description</label>
                                    
                                    <textarea name="description" class="form-control mt-2" id="description" cols="30" rows="5" placeholder="Write Description"><?php echo e(is_null(old('description'))?$notice->content:old('description')); ?></textarea>
                                    <input type="checkbox" name="descriptionNotApplicable" id="notDesc" /> <label for="notDesc">Description Not Applicable</label><br/>
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-sm btn-info">Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMP\htdocs\school\resources\views\admin\menu\notice\edit.blade.php ENDPATH**/ ?>