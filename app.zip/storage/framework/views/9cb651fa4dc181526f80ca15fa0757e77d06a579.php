
<?php $__env->startSection('title', 'Office Stuff'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-title">
    <h5>Office Stuff Member</h5>
    <p class="text-subtitle text-muted">Add, Delete Your Data</p>
</div>
<section class="section">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 col-12">
                            <div class="p-1">
                                <a href="<?php echo e(route('admin.officer')); ?>?page=office-stuff" class="btn btn-sm btn-success">Add New</a>
                            </div>
                            <?php if(session('delete')): ?>
                                <div class="alert alert-danger"><?php echo e(session('delete')); ?></div>
                            <?php endif; ?>
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Image</th>
                                        <th>Details</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!$officers->isEmpty()): ?>
                                    <?php $__currentLoopData = $officers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $officer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <img style="width:60px" class="thumbnail-img" src="<?php echo e(asset('storage/img/teacher').'/'.$officer->image); ?>" alt="Teacher Image"/>
                                        </td>
                                        <td>
                                            <h5 class="p-0"><?php echo e($officer->name); ?></h5>
                                            <h6><b><?php echo e($officer->job); ?></b><h6>
                                            <?php if($officer->description): ?>
                                                <p class="text-justify">
                                                    <?php echo e($officer->description); ?>

                                                </p>
                                            <?php endif; ?>
                                        </td>
                                        <td style="width:25%;">
                                            <div class="d-inline-block">
                                                
                                                <a href="<?php echo e(route('admin.officer.edit', ['id'=>$officer->id])); ?>?page=office-stuff" class="btn btn-sm btn-info">Update</a>
                                                
                                                <form action=<?php echo e(route('admin.officer.delete', ['id'=> $officer->id])); ?> method="POST" style="display:inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                                </form>
                                            </div>
                                            
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="4" class="text-sm text-muted text-center">No Data Available</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMP\htdocs\school\resources\views\admin\menu\administration\stuff.blade.php ENDPATH**/ ?>