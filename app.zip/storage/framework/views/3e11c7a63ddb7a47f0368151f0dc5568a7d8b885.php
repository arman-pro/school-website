<?php $__env->startSection('title', 'Celebrationers Expense List'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-title">
    <h5>Expense List</h5>
    <p class="text-subtitle text-muted">100 Years Celebrations Expense</p>
</div>
<section class="section">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4 col-sm-12">
                            <form action="<?php echo e(route('admin.100.expense')); ?>" method="post">
                                <?php if(session('message')): ?>
                                    <div class="alert alert-success"><?php echo e(session('message')); ?></div>
                                <?php endif; ?>
                                <?php if(session('error')): ?>
                                    <div class="alert alert-success"><?php echo e(session('error')); ?></div>
                                <?php endif; ?>
                                
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="expenseTitle">Expense Title</label>
                                    <input type="text" name='expenseTitle' id="expenseTitle" class="form-control" value="<?php echo e(old('expenseTitle')); ?>" placeholder="Ex Decoratoin Fare"/>
                                    <?php $__errorArgs = ['expenseTitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="expenseAmount">Expense Amount</label>
                                    <input type="number" name="expenseAmount" class="form-control" id="expenseAmount" value="<?php echo e(old('expenseAmount')); ?>" placeholder="Ex 5000"/>
                                    <?php $__errorArgs = ['expenseAmount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-sm btn-success"><b>Save</b></button>
                                    <a href="<?php echo e(route('admin.100.expense')); ?>" class="btn btn-sm btn-outline-danger"><b>Cancel</b></a>
                                </div>
                            </form>
                        </div>
                        <div class="col-md-8 col-sm-12">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Title</th>
                                        <th>Amount</th>
                                        <th>Date</th>
                                        <th>&nbsp;</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!$expenses->isEmpty()): ?>
                                    <?php $total=0; ?>
                                    <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $total = $total + $expense->amount; ?>
                                    <tr>
                                        <td>#<?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($expense->title); ?></td>
                                        <td><?php echo e($expense->amount); ?>/-</td>
                                        <td><?php echo e(date('j M y', strtotime($expense->created_at))); ?></td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <button id="btnGroupDrop1" type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i data-feather="settings" width="20"></i>
                                                </button>
                                                <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                                  <a class="dropdown-item text-info" href="#">Update</a>
                                                  <a class="dropdown-item text-danger" href="#">Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr>
                                            <td class="text-muted text-center" colspan="5">Expense Not Found!!!</td>
                                        </tr>
                                    <?php endif; ?>                                
                                </tbody>
                                <?php if($expenses->isNotEmpty()): ?>
                                <tfoot>
                                    <tr>
                                        <td><b>Total:</b></td>
                                        <td style="text-align: right" colspan="2"><?php echo e($total); ?>/-</td>
                                        <td colspan="2">&nbsp;</td>
                                    </tr>
                                </tfoot>
                                <?php endif; ?>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMP\htdocs\school\resources\views\admin\menu\100\expense.blade.php ENDPATH**/ ?>