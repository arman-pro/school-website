
<?php $__env->startSection('title', 'Create Slider'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-title">
    <h5>Create New Slider</h5>
    <p class="text-subtitle text-sm text-muted">Create, Edit and Delete your Sliders</p>
</div>
<section class="section">
    
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header pb-3">
                    <a href=<?php echo e(url('/admin/sliders')); ?> class="btn btn-sm btn-success">Back</a>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 col-12">
                            <?php if(session('message')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('message')); ?>

                                </div>
                            <?php endif; ?>
                           <form action=<?php echo e(route('slider.store')); ?> method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <p class="p-0 text-lg"><span class="text-danger "><b>*</b></span> Mark field must be required</p>
                                <div class="form-body">
                                    <div class="form-group">
                                        <label for="title">Title*</label>
                                        <input type="text" id="title" class="form-control" name="title" value="<?php echo e(old('title')); ?>"
                                            placeholder="Title*" autofocus="true" required />
                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-sm text-danger p-0"><b><?php echo e($message); ?></b></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                                   
                                    </div>
                                    <div class="form-group">
                                        <label for="sub-title">Sub Title*</label>
                                        <input type="text" id="sub-title" class="form-control" name="subtitle" value="<?php echo e(old('subtitle')); ?>" placeholder="Sub Title*" required/>
                                        <?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-sm text-danger p-0"><b><?php echo e($message); ?></b></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="thumbnail">Thumbnail*</label>
                                        <input type="file" id="thumbnail" class="form-control" name="thumbnail" accept=".png, .jpg, .jpeg" placeholder="Sub Title*" required />
                                        <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-sm text-danger p-0"><b><?php echo e($message); ?></b></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="description">Description*</label>
                                        <textarea name="description" id="description" cols="30" rows="3" class="form-control" placeholder="Description" required><?php echo e(old('description')); ?></textarea>
                                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-sm text-danger p-0"><b><?php echo e($message); ?><b/></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-12 d-flex justify-content-end">
                                        <button type="submit" class="btn btn-primary me-1 mb-1">Save</button>
                                    </div>
                                   
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamp\htdocs\school\resources\views/admin/menu/slider/create.blade.php ENDPATH**/ ?>